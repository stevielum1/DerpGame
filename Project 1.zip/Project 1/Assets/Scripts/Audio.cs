﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Audio : MonoBehaviour {

    public GameObject initial;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (!initial.GetComponent<AudioSource>().isPlaying && !this.gameObject.GetComponent<AudioSource>().isPlaying)
        {
            this.gameObject.GetComponent<AudioSource>().Play();
        }
	}

    void Awake()
    {
        DontDestroyOnLoad(initial);
        DontDestroyOnLoad(this.gameObject);
    }
}
