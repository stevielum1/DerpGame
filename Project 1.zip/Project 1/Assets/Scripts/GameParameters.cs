﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameParameters : MonoBehaviour {

    public float startDelay = 3.5f;
    public float level = 1.0f;

    public float lives = 3.0f;
    public float bombs = 3.0f;
    public float maxLives = 9.0f;
    public float maxBombs = 9.0f;

    public float playerSpeed = 5.0f;
    public float playerRespawnDelay = 2.0f;
    public float playerFireRate = 0.5f;
    public float playerBulletSpeed = 10.0f;

    public float enemyHealth = 10.0f;
    public float enemySpeed = 1.0f;
    public float enemyFireRate = 1.0f;

    public float enemyBulletSpeed = 0.5f;
    public float enemyBulletDestroyTime = 5.0f;

    public float bombDestroyTime = 10.0f;
    public float bombRespawnUpper = 20.0f;
    public float bombRespawnLower = 15.0f;

    public float oneUpDestroyTime = 10.0f;
    public float oneUpRespawnUpper = 40.0f;
    public float oneUpRespawnLower = 30.0f;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
