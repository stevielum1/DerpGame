﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerText : MonoBehaviour
{

    private float startDelay;
    public Text timerText;
    public GameObject gameParameters;

    //in seconds
    public float time;
    private float minutes;
    private float seconds;

    // Use this for initialization
    void Start()
    {
        timerText.text = "0:00";
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        time = -startDelay;
    }

    // Update is called once per frame
    void Update()
    {
        startDelay -= Time.deltaTime;
        time += Time.deltaTime;
        minutes = Mathf.Round((time - 30) / 60);
        seconds = Mathf.Round(time % 60);
        if (startDelay <= 0)
        {
            if (seconds < 10)
            {
                timerText.text = minutes.ToString() + ":0" + seconds.ToString();
            }
            else {
                timerText.text = minutes.ToString() + ":" + seconds.ToString();
            }
        }
    }
}
