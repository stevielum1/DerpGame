﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletSpawn : MonoBehaviour
{

    public float startDelay;
    public float fireRate;
    private float nextFire;
    public GameObject enemyBullet;
    public GameObject gameParameters;

    // Use this for initialization
    void Start()
    {
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        fireRate = gameParameters.GetComponent<GameParameters>().enemyFireRate;
        nextFire = 0.0f;
    }

    // Update is called once per frame
    void Update()
    {
        startDelay -= Time.deltaTime;
        if (startDelay <= 0)
        {
            if (Time.time > nextFire)
            {
                nextFire = Time.time + fireRate;
                Instantiate(enemyBullet, this.gameObject.transform.position, this.gameObject.transform.rotation);
            }
        }
    }
}
