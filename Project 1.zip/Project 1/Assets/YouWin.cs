﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class YouWin : MonoBehaviour
{
    private float winTime;
    private bool isWin;
    public GameObject enemy;
    public Text winText;

    // Use this for initialization
    void Start()
    {
        winText.text = "";
        isWin = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (enemy.GetComponent<Enemy>().health <= 0.0f)
        {
            winTime = Time.time + 1.0f;
            isWin = true;
        }
        else
        {
            isWin = false;
        }

        if (isWin)
        {
            if (winTime < Time.time)
            {
                winText.text = "YOU WIN";
            }
        }
        else
        {
            winText.text = "";
        }
    }
}
