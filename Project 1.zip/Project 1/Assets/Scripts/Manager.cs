﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{
    private float startDelay;
    private bool isPaused;
    private float winTime;
    public GameObject darken;
    public GameObject pauseText;
    public GameObject gameParameter;
    public GameObject enemy;
    public GameObject winText;
    public GameObject nextLevel;

    // Use this for initialization
    void Start()
    {
        startDelay = gameParameter.GetComponent<GameParameters>().startDelay;
        isPaused = false;
        pauseText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        startDelay -= Time.deltaTime;
        if (startDelay <= 0)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (isPaused)
                {
                    pauseText.SetActive(false);
                    darken.SetActive(false);
                    Time.timeScale = 1;
                    isPaused = false;
                }
                else
                {
                    pauseText.SetActive(true);
                    darken.SetActive(true);
                    Time.timeScale = 0;
                    isPaused = true;
                }
            }
            if (enemy.GetComponent<Enemy>().health <= 0)
            {
                StartCoroutine(showWin());
            }
        }
    }

    public void QuitApp()
    {
        Application.Quit();
    }

    IEnumerator showWin()
    {
        yield return new WaitForSecondsRealtime(2);
        winText.SetActive(true);
        nextLevel.SetActive(true);
    }

    public void loadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1, LoadSceneMode.Single);
    }
}
