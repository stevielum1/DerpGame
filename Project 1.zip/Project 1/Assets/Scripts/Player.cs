﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float lives;
    public float bombs;
    private float speed;
    private float startDelay;
    private float respawnDelay;
    private float fireRate;
    private float nextFire;
    private float nextRespawn;
    private bool respawnFlag;
    private bool isDead;
    private float x_pos;
    private float y_pos;

    public GameObject gameParameters;
    public GameObject playerBullet;
    public GameObject bombRing;
    public GameObject playerDead;
    public GameObject[] playerBulletSpawn;

    void OnTriggerEnter2D(Collider2D obj)
    {

        if ((obj.name == "Enemy Bullet" || obj.name == "Enemy Bullet(Clone)") && isDead == false)
        {
            //play dead animation
            Instantiate(playerDead, this.gameObject.transform.position, Quaternion.identity);

            //move player to default position
            this.gameObject.transform.position = new Vector3(0, -4, 0);

            lives--;
            this.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            respawnFlag = true;
            isDead = true;

            nextRespawn = Time.time + respawnDelay;
            Debug.Log("next: " + nextRespawn);
            Debug.Log("respawn: " + respawnDelay);
            Debug.Log("time: " + Time.time);
        }

        if (obj.name == "OneUp" || obj.name == "OneUp(Clone)")
        {
            Destroy(obj.gameObject);
            if (lives < gameParameters.GetComponent<GameParameters>().maxLives)
            {
                lives++;
            }
        }

        if (obj.name == "Bomb" || obj.name == "Bomb(Clone)")
        {
            Destroy(obj.gameObject);
            if (bombs < gameParameters.GetComponent<GameParameters>().maxBombs)
            {
                bombs++;
            }
        }

        if (obj.name == "Bottom")
        {
            this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x, 4.7f, 0.0f);
        }

        if (obj.name == "Top")
        {
            this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x, -4.7f, 0.0f);
        }

        if (obj.name == "Left Wall")
        {
            this.gameObject.transform.position = new Vector3(7.35f, this.gameObject.transform.position.y, 0.0f);
        }

        if (obj.name == "Right Wall")
        {
            this.gameObject.transform.position = new Vector3(-7.35f, this.gameObject.transform.position.y, 0.0f);
        }
    }

    // Use this for initialization
    void Start()
    {
        playerBulletSpawn = GameObject.FindGameObjectsWithTag("PlayerBulletSpawn");
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        lives = gameParameters.GetComponent<GameParameters>().lives;
        bombs = gameParameters.GetComponent<GameParameters>().bombs;
        speed = gameParameters.GetComponent<GameParameters>().playerSpeed;
        respawnDelay = gameParameters.GetComponent<GameParameters>().playerRespawnDelay;
        fireRate = gameParameters.GetComponent<GameParameters>().playerFireRate;
        nextFire = 0.0f;
        nextRespawn = 0.0f;
        respawnFlag = false;
        isDead = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (startDelay < Time.time)
        {
            x_pos = Input.GetAxis("Horizontal") * speed * Time.deltaTime;
            y_pos = Input.GetAxis("Vertical") * speed * Time.deltaTime;

            //hold left shift to move at half speed
            if (Input.GetKey(KeyCode.LeftShift))
            {
                x_pos *= 0.5f;
                y_pos *= 0.5f;
            }

            //z to shoot only if alive
            if (Input.GetKey(KeyCode.Z) && nextFire < Time.time && isDead == false)
            {
                nextFire = Time.time + fireRate;
                for (int index = 0; index < playerBulletSpawn.Length; index++)
                {
                    Instantiate(playerBullet, playerBulletSpawn[index].transform.position, playerBulletSpawn[index].transform.rotation);
                }
            }

            //x to bomb only if alive
            if (Input.GetKeyDown(KeyCode.X) && bombs > 0 && isDead == false)
            {
                bombs--;
                Instantiate(bombRing, this.gameObject.transform.position, Quaternion.identity);
            }

            if (Time.time > nextRespawn && respawnFlag && lives > 0)
            {
                this.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                Instantiate(bombRing, this.gameObject.transform.position, Quaternion.identity);
                respawnFlag = false;
                isDead = false;
            }

            //only move if player is alive
            if (isDead == false)
            {
                this.gameObject.transform.Translate(x_pos, y_pos, 0.0f);
            }
        }
    }
}