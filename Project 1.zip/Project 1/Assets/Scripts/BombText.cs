﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BombText : MonoBehaviour {

    public Text bombText;
    public GameObject player;

	// Use this for initialization
	void Start () {
        bombText.text = "Bombs: " + player.GetComponent<Player>().bombs.ToString();
	}
	
	// Update is called once per frame
	void Update () {
        bombText.text = "Bombs: " + player.GetComponent<Player>().bombs.ToString();
    }
}
