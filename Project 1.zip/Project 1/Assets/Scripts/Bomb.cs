﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour {

    public GameObject gameParameters;

	// Use this for initialization
	void Start () {
        Destroy(this.gameObject, gameParameters.GetComponent<GameParameters>().bombDestroyTime);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
