﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundGenerator : MonoBehaviour
{
    public GameObject star;
    private GameObject clone;
    private float size;

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        clone = Instantiate(star, new Vector3(Random.Range(-6.34f, 11.34f), Random.Range(-4.94f, 4.94f), 0.0f), Quaternion.identity);
        size = Random.Range(2.0f, 5.0f);
        clone.transform.localScale = new Vector3(size, size, 1.0f);
    }
}
