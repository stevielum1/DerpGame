﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour {

    public float speed;
    public GameObject gameParameters;

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.name == "Enemy" || obj.name == "Top")
        {
            Destroy(this.gameObject);
        }
    }

	// Use this for initialization
	void Start () {
        Destroy(this.gameObject, 3.0f);
        speed = gameParameters.GetComponent<GameParameters>().playerBulletSpeed;
	}
	
	// Update is called once per frame
	void Update () {
        this.gameObject.transform.Translate(0.0f, speed * Time.deltaTime, 0.0f);
	}
}
