﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBulletSpawn : MonoBehaviour
{/*
    public float start_delay = 3.5f;
    public GameObject playerBullet;
    public bool active = true;

    // Use this for initialization
    void Start()
    {
        this.gameObject.SetActive(active);
    }

    // Update is called once per frame
    void Update()
    {
        if (start_delay <= Time.time)
        {
            
        }
    }*/
}
