﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameParameters : MonoBehaviour {

    public float startDelay = 3.5f;

    public float lives = 3.0f;
    public float bombs = 3.0f;
    public float maxLives = 9.0f;
    public float maxBombs = 9.0f;
    public float playerSpeed = 5.0f;
    public float playerRespawnDelay = 2.0f;
    public float playerFireRate = 0.5f;

    public float playerBulletSpeed = 10.0f;

    public float enemyHealth = 10.0f;
    public float enemySpeed = 1.0f;

    public float enemyFireRate = 1.0f;
    public float enemyBulletSpeed = 0.5f;
    public float enemyBulletDestroyTime = 5.0f;

    public float bombDestroyTime = 10.0f;
    public float bombRespawnUpper = 20.0f;
    public float bombRespawnLower = 15.0f;

    public float oneUpDestroyTime = 10.0f;
    public float oneUpRespawnUpper = 40.0f;
    public float oneUpRespawnLower = 30.0f;

    public GameObject player;
    public GameObject playerBullet;
    public GameObject enemy;
    public GameObject enemyBullet;
    public GameObject enemyBulletSpawn;
    public GameObject bomb;
    public GameObject bombSpawner;
    public GameObject oneUp;
    public GameObject oneUpSpawner;

	// Use this for initialization
	void Start () {
        player.GetComponent<Player>().startDelay = startDelay;
        player.GetComponent<Player>().lives = lives;
        player.GetComponent<Player>().bombs = bombs;
        player.GetComponent<Player>().speed = playerSpeed;
        player.GetComponent<Player>().respawnDelay = playerRespawnDelay;
        player.GetComponent<Player>().fireRate = playerFireRate;

        playerBullet.GetComponent<PlayerBullet>().speed = playerBulletSpeed;

        enemy.GetComponent<Enemy>().startDelay = startDelay;
        enemy.GetComponent<Enemy>().health = enemyHealth;
        enemy.GetComponent<Enemy>().speed = enemySpeed;

        enemyBulletSpawn.GetComponent<EnemyBulletSpawn>().startDelay = startDelay;
        enemyBulletSpawn.GetComponent<EnemyBulletSpawn>().fireRate = enemyFireRate;

        enemyBullet.GetComponent<EnemyBullet>().speed = enemyBulletSpeed;
        enemyBullet.GetComponent<EnemyBullet>().destroyTime = enemyBulletDestroyTime;

        bomb.GetComponent<Bomb>().destroyTime = bombDestroyTime;

        bombSpawner.GetComponent<BombSpawner>().startDelay = startDelay;
        bombSpawner.GetComponent<BombSpawner>().respawnLower = bombRespawnLower;
        bombSpawner.GetComponent<BombSpawner>().respawnUpper = bombRespawnUpper;

        oneUp.GetComponent<OneUp>().destroyTime = oneUpDestroyTime;

        oneUpSpawner.GetComponent<OneUpSpawner>().startDelay = startDelay;
        oneUpSpawner.GetComponent<OneUpSpawner>().respawnLower = oneUpRespawnLower;
        oneUpSpawner.GetComponent<OneUpSpawner>().respawnUpper = oneUpRespawnUpper;
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
