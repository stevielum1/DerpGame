﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    private float startDelay;
    private float speed;
    public float health;
    public GameObject gameParameters;

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.name == "Right Wall" || obj.name == "Left Wall")
        {
            speed = -speed;
        }

        if (obj.name == "Player Bullet" || obj.name == "Player Bullet(Clone)")
        {
            health--;
        }
    }

	// Use this for initialization
	void Start () {
        speed = gameParameters.GetComponent<GameParameters>().enemySpeed;
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        health = gameParameters.GetComponent<GameParameters>().enemyHealth;
	}
	
	// Update is called once per frame
	void Update () {
        if (startDelay < Time.time)
        {
            this.gameObject.transform.Translate(speed * Time.deltaTime, 0.0f, 0.0f);
        }
        if(health <= 0)
        {
            this.gameObject.SetActive(false);
        }
	}
}
