﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelText : MonoBehaviour
{
    private float level;
    public Text levelText;
    public GameObject gameParameters;

    // Use this for initialization
    void Start()
    {
        level = gameParameters.GetComponent<GameParameters>().level;
    }

    // Update is called once per frame
    void Update()
    {
        levelText.text = "Level: " + level;
    }
}