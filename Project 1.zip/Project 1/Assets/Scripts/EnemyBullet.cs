﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour {

    public float destroyTime;
    public float speed;
    public GameObject enemy;
    public GameObject gameParameters;

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.name == "BombRing" || obj.name == "BombRing(Clone)")
        {
            Destroy(this.gameObject);
        }

        if (obj.name == "Bottom")
        {
            this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x, 4.8f, 0.0f);
        }
        
        if (obj.name == "Top")
        {
            Destroy(this.gameObject);
            //this.gameObject.transform.position = new Vector3(this.gameObject.transform.position.x, -4.8f, 0.0f);
        }
        
        if (obj.name == "Left Wall")
        {
            this.gameObject.transform.position = new Vector3(7.35f, this.gameObject.transform.position.y, 0.0f);
        }

        if (obj.name == "Right Wall")
        {
            this.gameObject.transform.position = new Vector3(-6.2f, this.gameObject.transform.position.y, 0.0f);
        }
    }

    // Use this for initialization
    void Start()
    {
        Destroy(this.gameObject, destroyTime);
        speed = gameParameters.GetComponent<GameParameters>().enemyBulletSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        this.gameObject.transform.Translate(0, speed * Time.deltaTime, 0);
    }
}
