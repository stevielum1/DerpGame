﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OneUp : MonoBehaviour {

    public GameObject gameParameters;

	// Use this for initialization
	void Start () {
        Destroy(this.gameObject, gameParameters.GetComponent<GameParameters>().oneUpDestroyTime);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
