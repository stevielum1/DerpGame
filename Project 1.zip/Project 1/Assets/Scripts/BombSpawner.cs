﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombSpawner : MonoBehaviour {

    private float startDelay;
    private float respawnUpper;
    private float respawnLower;
    private float nextSpawn;
    public GameObject bomb;
    public GameObject gameParameters;

    // Use this for initialization
    void Start () {
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        respawnUpper = gameParameters.GetComponent<GameParameters>().bombRespawnUpper;
        respawnLower = gameParameters.GetComponent<GameParameters>().bombRespawnLower;
        nextSpawn = Random.Range(respawnLower, respawnUpper);
    }
	
	// Update is called once per frame
	void Update () {
        if (startDelay < Time.time)
        {
            if (Time.time > nextSpawn)
            {
                nextSpawn = Time.time + Random.Range(respawnLower, respawnUpper);
                Instantiate(bomb, new Vector3(Random.Range(-7.4f, 7.4f), Random.Range(-4.0f, 0.0f), 0), Quaternion.identity);
            }
        }
    }
}
