﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public float startDelay;
    public float speed;
    public float health;
    private GameObject[] enemyBulletSpawn;
    public GameObject gameParameters;

    void OnTriggerEnter2D(Collider2D obj)
    {
        if (obj.name == "Right Wall" || obj.name == "Left Wall")
        {
            speed = -speed;
        }

        if (obj.name == "Player Bullet" || obj.name == "Player Bullet(Clone)")
        {
            health--;
        }
    }

    // Use this for initialization
    void Start()
    {
        speed = gameParameters.GetComponent<GameParameters>().enemySpeed;
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        health = gameParameters.GetComponent<GameParameters>().enemyHealth;
        enemyBulletSpawn = GameObject.FindGameObjectsWithTag("EnemyBulletSpawn");
    }

    // Update is called once per frame
    void Update()
    {
        startDelay -= Time.deltaTime;
        if (startDelay <= 0)
        {
            this.gameObject.transform.Translate(speed * Time.deltaTime, 0.0f, 0.0f);
            if (health <= 0)
            {
                for (int index = 0; index < enemyBulletSpawn.Length; index++)
                {
                    enemyBulletSpawn[index].SetActive(false);
                }
                this.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            }
        }
    }
}
