﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBullet : MonoBehaviour {

    private float speed;
    public GameObject gameParameters;

    void OnTriggerEnter2D(Collider2D obj)
    {
        if(obj.name == "Top" || obj.name == "Spawner")
        {
            Destroy(this.gameObject);
        }
    }

	// Use this for initialization
	void Start () {
        speed = gameParameters.GetComponent<GameParameters>().playerBulletSpeed;
	}
	
	// Update is called once per frame
	void Update () {
        this.gameObject.transform.Translate(0.0f, speed * Time.deltaTime, 0.0f);
	}
}
