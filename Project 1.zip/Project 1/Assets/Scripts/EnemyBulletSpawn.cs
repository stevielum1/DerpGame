﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletSpawn : MonoBehaviour {

    private float startDelay;
    private float fireRate;
    private float nextFire;
    public GameObject enemyBullet;
    public GameObject gameParameters;

    // Use this for initialization
    void Start () {
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
        fireRate = gameParameters.GetComponent<GameParameters>().enemyFireRate;
        nextFire = 0.0f;
	}
	
	// Update is called once per frame
	void Update () {
        if (startDelay < Time.time)
        {
            if (Time.time > nextFire)
            {
                nextFire = Time.time + fireRate;
                Instantiate(enemyBullet, this.gameObject.transform.position, this.gameObject.transform.rotation);
            }
        }
    }
}
