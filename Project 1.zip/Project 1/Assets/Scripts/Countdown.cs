﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Countdown : MonoBehaviour {

    private float startDelay;
    public Text countdown;
    public GameObject gameParameters;

	// Use this for initialization
	void Start () {
        startDelay = gameParameters.GetComponent<GameParameters>().startDelay;
	}
	
	// Update is called once per frame
	void Update () {
        startDelay -= Time.deltaTime;
        countdown.text = Mathf.Round(startDelay).ToString();
        if(0 <= startDelay && startDelay <= 0.5)
        {
            countdown.text = "GO";
        } else if(startDelay < 0)
        {
            countdown.text = "";
        }
    }
}
