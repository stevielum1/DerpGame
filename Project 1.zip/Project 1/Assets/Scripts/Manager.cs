﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{
    private float startDelay;
    private bool isPaused;
    private float winTime;

    public GameObject darken;
    public GameObject pauseText;

    public GameObject gameParameter;

    public GameObject player;
    public GameObject enemy;

    public GameObject winText;
    public GameObject nextLevelButton;
    public GameObject mainMenuButton;
    public GameObject restartButton;
    public GameObject gameOverText;

    // Use this for initialization
    void Start()
    {
        startDelay = gameParameter.GetComponent<GameParameters>().startDelay;
        isPaused = false;
        pauseText.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        startDelay -= Time.deltaTime;
        if (startDelay <= 0)
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (isPaused)
                {
                    pauseText.SetActive(false);
                    darken.SetActive(false);
                    mainMenuButton.SetActive(false);
                    restartButton.SetActive(false);
                    Time.timeScale = 1;
                    isPaused = false;
                }
                else
                {
                    pauseText.SetActive(true);
                    darken.SetActive(true);
                    mainMenuButton.SetActive(true);
                    restartButton.SetActive(true);
                    Time.timeScale = 0;
                    isPaused = true;
                }
            }

            if (enemy.GetComponent<Enemy>().health <= 0)
            {
                StartCoroutine(showWin());
            }

            if (player.GetComponent<Player>().lives <= 0)
            {
                StartCoroutine(showGameOver());
            }
        }
    }

    public void loadMainMenu()
    {
        SceneManager.LoadScene(0, LoadSceneMode.Single);
        Time.timeScale = 1.0f;
    }

    public void restartLevel1()
    {
        SceneManager.LoadScene(1, LoadSceneMode.Single);
        Time.timeScale = 1.0f;
    }

    IEnumerator showWin()
    {
        yield return new WaitForSecondsRealtime(2);
        winText.SetActive(true);
        if (SceneManager.GetActiveScene().buildIndex < 3)
        {
            nextLevelButton.SetActive(true);
        }
    }

    IEnumerator showGameOver()
    {
        yield return new WaitForSecondsRealtime(2);
        gameOverText.SetActive(true);
        mainMenuButton.SetActive(true);
        restartButton.SetActive(true);
    }

    public void loadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1, LoadSceneMode.Single);
    }
}
